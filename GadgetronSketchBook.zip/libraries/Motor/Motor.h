#ifndef MOTOR_H
#define MOTOR_H

#ifdef ARDUINO
#include <Arduino.h>
#else
#include "arduPi.h"
#endif

class GadgetManager;
#include "GadgetManager.h"
#define MOTOR_PIN_ARRAY {STBY, PWMA, AIN1, AIN2, PWMB, BIN1, BIN2} 
#define MOTOR_PIN_C 7

#define POLARITY_BIT 2
#define DIRECTION_BIT 4
#define MOVING_BIT 8

#define MOTOR_A_ORIG 1
#define MOTOR_B_ORIG 0
#define MOTOR_A ( (state & DIRECTION_BIT) ? MOTOR_B_ORIG : MOTOR_A_ORIG )
#define MOTOR_B ( (state & DIRECTION_BIT) ? MOTOR_A_ORIG : MOTOR_B_ORIG )

/**
 * Filename: Motor.h \n 
 * Author: Michael Gonzalez \n 
 * Description: This class controls the Sparkfun Motor Driver TB6612FNG. It\n
 * provides methods to move the motors forward and backwards, to spin left\n
 * and right, to stop the motors, and to provide information about the motor\n
 * driver's state.
 */
class Motor
{
   public:
    /**
	   * This is the constructor to make your motor.
	   * The arguments are the various pins that your motor connects to on its 
	   * board.
	   */
      Motor( uint8_t STBY, uint8_t PWMA, uint8_t AIN1, uint8_t AIN2, 
             uint8_t PWMB, uint8_t BIN1, uint8_t BIN2); 
	  /**
	   * Move the motors forward at full speed
	   */
      void forward();
	  /**
	   * Move the motors forward at a definable speed. \n
	   * Valid input range is 0 (Slowest Speed/Stopped) to 255 (Fastest Speed)
	   */
      void forward(uint8_t speed);
      void accelerateForward( uint8_t startSpeed, uint8_t endSpeed, int rate );
      void accelerateBackward( uint8_t startSpeed, uint8_t endSpeed, int rate );
	  /**
	   * Move the motors backwards at full speed
	   */
      void backward();
	  /**
	   * Move the motors backwards at a definable speed.\n
	   * Valid input ranges 0 (Slowest Speed/Stopped) to 255 (Fastest Speed)
	   */
      void backward(uint8_t speed);
	  /**
	   * Move the motors to spin a gadget full speed to the left
	   */
      void spinLeft();
	  /**
	   * Move the motors to spin a gadget at a definable speed to the left.\n
	   * Valid input ranges from 0 (Slowest Speed/Stopped) to 255 (Fastest Speed)
	   */
      void spinLeft(uint8_t speed);
	   /**
	   * Move the motors to spin a gadget full speed to the right
	   */
      void spinRight();
	  /**
	   * Move the motors to spin a gadget at a definable speed to the right.\n
	   * Valid input ranges from 0 (Slowest Speed/Stopped) to 255 (Fastest Speed)
	   */
      void spinRight(uint8_t speed );
	  /**
	   * Move the motors forward while drifting to the right at top speed.\n
	   * WARNING: This function is still in testing and is not guaranteed 
	   * to work
	   */
      void forwardAndRight();
	  /**
	   * Move the motors forward while drifting to the right at a definable 
	   * speed.\n
	   * WARNING: This function is still in testing and is not guaranteed 
	   * to work
	   */
      void forwardAndRight(uint8_t speed, float ratio);
	  /**
	   * Move the motors forward while drifting to the left at top speed.\n
	   * WARNING: This function is still in testing and is not guaranteed 
	   * to work
	   */
      void forwardAndLeft();
	  /**
	   * Move the motors forward while drifting to the left at a definable 
	   * speed.\n
	   * WARNING: This function is still in testing and is not guaranteed 
	   * to work
	   */
      void forwardAndLeft(uint8_t speed, float ratio);
	  /**
	   * Sets the motors up to run. This method must be called before use!
	   */
      void setup();
	  /**
	   * Sends the stop signal to the motors
	   */
      void stop();
	  /**
	   * Sends the stop signal to the motors and lowers movement pins
	   */
      void brake();
	  /**
	   * Returns true if the motors are running, else false
	   */
      bool isMoving();
	  /**
	   * Changes spinLeft to spinRight and spinRight to spinLeft
	   */
      unsigned char swapDirections();
      uint8_t STBY, PWMA, AIN1, AIN2, PWMB, BIN1, BIN2;
	  /**
	   * Changes forward to backward and backward to forward
	   */
      void changePolarity();
      

      //Prevent the motor pins from doing anything
      //Call before setup()
      void disable();   
  private:
      void move(uint8_t motor, uint8_t speed, uint8_t direction);
      void _moveBoth( uint8_t speed, uint8_t polarity );
      int polarity;
      bool _isMoving;
      void accelerate( uint8_t startSpeed, uint8_t endSpeed, int rate, void (Motor::*)(uint8_t i) );
      void claimPins();
      unsigned char state = 0;


      //Deactivates all pins associated with the motor
      //No pinMode, no digitalWrites, no analogWrites
      //For serial debugging when there are pin conflicts

};
#endif
