#ifndef ROTARY
#define ROTARY

#include <MomentaryButton.h>
#include <PinChangeInt.h>
#include <Arduino.h> 
class RotaryEncoder {
	int pinA, pinB, currentPos, maxPos, pinButton;
	uint8_t enc_prev_pos;
	uint8_t enc_flags;
  MomentaryButton button;
	public:
		RotaryEncoder( int pin_button, int pin_a, int pin_b );
		void setup();
		void poll();
		int getCurrentPos();
		void setMaxPos( int max );
    uint8_t isPressed();
    uint8_t wasPressed();
};
#endif
