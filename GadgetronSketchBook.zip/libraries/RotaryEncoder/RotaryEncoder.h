#ifndef ROTARY_ENCODER
#define ROTARY_ENCODER
#include <Arduino.h> 
#include <PinChangeInt.h>   //Still need to #include in the main .ino code too
#include <MomentaryButton.h>
class RotaryEncoder {
	int pinA, pinB, currentPos, maxPos, pinButton;
	uint8_t enc_prev_pos;
	uint8_t enc_flags;
  MomentaryButton button;
	public:
		RotaryEncoder( int pin_button, int pin_a, int pin_b );
		void setup();
		void poll();
		int getCurrentPos();
		void setMaxPos( int max );
    uint8_t isPressed();
    uint8_t wasPressed();
}
#endif
