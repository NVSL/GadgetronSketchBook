#ifndef LED_INCLUDED
#define LED_INCLUDED

#include "Arduino.h"

class LED {
    enum {ON, OFF};    //For state stuff

    int pin;   //The pin the LED is connected to
    int onTime;    //The time for the LED to be on during blinking
    int offTime;   //The time for the LED to be off during blinking
    int state;     //The LED's current state (on or off)
    bool blinking; //Whether the LED is 
    unsigned long nextTransition;  //when the next transition time should be when blinking

    public:

    /**
     * Constructor that assigns LED pin
     */
    LED(int pin): 
        pin(pin), 
        onTime(onTime), 
        offTime(offTime) {
            state = OFF;
            blinking = false;
        }

    /** 
     * This function will update the current state of the LED. If the LED \n
     * should blink(), then this function will ensure that happens. To work \n
     * correctly, this function should be placed at the top of the main \n
     * Arduino's update function. The programmer should take care to call \n
     * few or short calls to delay() to ensure the LED blinks on time.  
     */
    void update() {
        if (blinking == true) {
            if (millis() > nextTransition) {
                toggle();
                if (state == OFF)
                {
                    nextTransition = millis() + offTime;
                }
                else if (state == ON)
                {
                    nextTransition = millis() + onTime;
                }
            }
        }
    }

    /**
     * This function prepares the LED to blink when update() is next called. \n
     * It also specifies the amount of time the LED should stay on and off 
     * while it is blinking.
     */
    void blink(int on, int off) {
        onTime = on;
        offTime = off;
        blink();
    }

    /**
     * This function prepares the LED to blink when update() is next called. \n
     */
    void blink() {
        blinking = true;
        nextTransition = millis() + onTime;
    }

    /**
     * Returns whether the LED is in a blinking state or not
     */
    bool isBlinking() {
        return blinking;
    }

    /** 
     * Turns the LED to the state opposite of what it currently is \n
     * If the LED is on, then this function turns it off. \n
     * If the LED is off, then this function turns it on. \n
     */
    void toggle() {
        if (state == ON) {
            turnOff();
        } else if (state == OFF) {
            turnOn();
        }
    }

    /**
     * Turns on the LED
     */
    void turnOn() {
        state = ON;
        digitalWrite(pin, HIGH);
    }

    /**
     * Turns off the LED
     */
    void turnOff() {
        state = OFF;
        digitalWrite(pin, LOW);
    }

    /**
     * Basic setup causes the LED to blink in 500 ms intervals
     */
    void setup() {
        pinMode(pin, OUTPUT);
        digitalWrite(pin, LOW);
        onTime = offTime = 500;
    }

};
#endif
