#ifndef BUZZER_H
#define BUZZER_H

#include <Arduino.h>
#include "NoteFrequencyTable.h"

/** Filename: Buzzer.h \n
 *  Author: Michael Gonzalez \n
 *  Description: This file provides a simple interface to control piezo buzzers \n
 *               on Arduino projects. A note frequency lookup table is provided \n
 *               to facilitate easy musical note entry. For example, a user \n
 *               only has to pass NOTE_A4 to the playNote function to play the A \n
 *               note at the 4th octave rather than having to specify 440 as \n
 *               the frequency to play A4.
 */
class Buzzer {
  uint8_t pin;
  public:
    /** Buzzer constructor. */ 
    Buzzer(uint8_t pin); 
    /** Plays the given frequency off the buzzer until turnOff is called */
    void playNote( int frequency );
    /** Plays the given frequency off the buzzer for noteLength milliseconds */
    void playNote( int frequency, int noteLength );
    /** Stops the buzzer from playing any sounds */
    void turnOff();
    /** A dummy setup function that doesn't actually do anything */
    void setup();
};
#endif
