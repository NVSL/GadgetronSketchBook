#ifndef BUZZER_H
#define BUZZER_H

#include <Arduino.h>
#include "NoteFrequencyTable.h"

/** Filename: Buzzer.h \n
 *  Author: Michael Gonzalez \n
 *  Description: This file provides a simple interface to control piezo buzzers
 *               on Arduino projects. A note frequency lookup table is provided
 *               to facilitate easy musical note entry. For example, a user 
 *               only has to pass NOTE_A4 to the playNote function to play the A
 *               note at the 4th octave rather than having to specify 440 as 
 *               the frequency to play A4.
 */
class Buzzer {
  int pin;
  public:
    /** Buzzer constructor. */ 
    Buzzer(int pin); 
    /** Plays the given frequency off the buzzer until turnOff is called */
    void playNote( int frequency );
    /** Plays the given frequency off the buzzer for noteLength milliseconds */
    void playNote( int frequency, int noteLength );
    /** Stops the buzzer from playing any sounds */
    void turnOff();
    /** A dummy setup function that doesn't actually do anything */
    void setup();
};
#endif
