#ifndef SERVO_WRAPPER
#define SERVO_WRAPPER

class GadgetManager;
#include <Servo.h>
#include <GadgetManager.h>

/**
 * Filename: ServoMotor.h \n
 * Author: Michael Gonzalez \n
 * Description: This class controls servo motors attached to an Arduino.\n
 * It provides support for both continuous rotation and postional rotation \n 
 * servos. By calling rotate, you can specify how you want the servo to move. \n
 * The class wraps the Arduino Servo library to be compatible with the \n
 * Gadgetron tool-chain and the GadgetManager. 
 */
class ServoMotor {
  // The GadgetManager should be able to call block and enable but we want to
  // hide this from the user.
  friend class GadgetManager;
  public:
    /**
     * This is the constructor to make your ServoMotor. \n
     * The pin parameter is the data pin \n
     */
    ServoMotor( int pin );
	  /**
	   * Sets the servo up to run and registers it with the GadgetManager. This \n
     * method must be called before use!
	   */
    void setup();
    /**
     * Attaches the servo to data pin. This is implicitly called in setup; \n
     * but, must be called if you want to use the servo again after calling \n
     * detach.
     */
    void attach();
    /**
     * Detaches the servo from its PWM timer. \n
     * For students: \n
     * This function halts the communication stream between the micro \n
     * processor and the servo itself. This can be useful if your motoros \n
     * continually grind against themselves, or, to simply save power. \n
     */
    void detach();
    /**
     * Rotates the servo from its initial position to degrees. \n
     * This method also reclaims the PWM timer if the servo has lost it and \n
     * can re-claim it.
     */
    void rotate( int degrees );
  private:
    // Detaches servo from timer and prevents user from accessing servo
    void block();
    // Allows servo to access timer but does not immediately re-claim it
    void enable();
    /*
     * Internal implementation of detach logic. \n 
     * Does not modify state bits \n
     * For future Gadgetron Developers: \n
     * The Arduino Servo library on which this function depends on doesn't \n 
     * fully function. It seems to disable the PWM timer the servo took up \n 
     * after it detaches. The solution right now is hardcoded into this \n
     * but is specically tailored to the ATMega328. Whether this function \n
     * works on other processors is unknown.
     */
    void _detach();

    // The Arduino Library Servo
    Servo servo;
    // Inside the Gadget Manager, every servo is a node in a
    // linked list of servos
    ServoMotor * next;
    // Data pin
    int pin;

    // State Bit Vector
    // Uses state definitions from GadgetManager
    unsigned char state;
};


#endif
